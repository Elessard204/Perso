"""Règles de facturation : fonctions pures, sans réseau. Paramètres dans regles.toml."""

from __future__ import annotations

import math
import re
import tomllib
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

from modele import Alerte, EntreeTemps, Facture, Ligne


@dataclass
class Regles:
    pas_minutes: int
    marge: float
    refacturer_taxes: bool
    regle_transports: str
    ecart_sous_total: float
    jours_max_facture: int
    montant_max_ligne: float
    heures_max_jour: float
    transport_max_minutes: int = 60
    marge_minimum: float = 0.0
    tarifs: dict = field(default_factory=dict)          # type de bon -> {service, heure, transport}
    tarifs_autres: dict = field(default_factory=dict)   # services jamais appliqués automatiquement
    tarif_progression: str = "Appel de service"         # type dont Progression met les taux par défaut
    cout_horaire_defaut: float = 0.0                    # taux de base moyen d'un technicien; 0 = inconnu
    couts_techniciens: dict = field(default_factory=dict)  # nom du technicien -> taux de base
    charges_das: float = 0.12                           # charges de l'employeur, fraction du taux de base
    charges_vacances: float = 0.06                      # 6 % pour tous les employés (paie Progim)
    charges_feries: float = 0.05
    km_taux: float = 0.61                               # $ par km
    km_seuil_ecart: float = 10.0                        # écart déclaré / payé signalé au-delà (km)
    km_debut_reference: date = date(2026, 11, 8)        # dimanche : début d'une période de paie
    salaire_fixe: list = field(default_factory=list)    # techniciens à salaire fixe : route jamais refacturée
    produits_forfait: list = field(default_factory=list)  # produits forfaitaires (ex. bacs) : heures non facturées
    seuil_rabais: float = 50.0                          # écart signalé entre le temps inscrit et le facturé ($)

    @property
    def facteur_charges(self) -> float:
        """Multiplicateur qui transforme un taux de base en coût chargé."""
        somme = sum(Decimal(str(x)) for x in (self.charges_das, self.charges_vacances, self.charges_feries))
        return float(1 + somme)


def charger_regles(chemin: Path) -> Regles:
    d = tomllib.loads(Path(chemin).read_text(encoding="utf-8"))
    g = d["garde_fous"]
    return Regles(
        pas_minutes=int(d["heures"]["pas_minutes"]),
        marge=float(d["materiel"]["marge"]),
        refacturer_taxes=bool(d["materiel"].get("refacturer_taxes", False)),
        regle_transports=str(d["transports"]["regle"]),
        ecart_sous_total=float(g["ecart_sous_total"]),
        jours_max_facture=int(g["jours_max_facture"]),
        montant_max_ligne=float(g["montant_max_ligne"]),
        heures_max_jour=float(g["heures_max_jour"]),
        transport_max_minutes=int(d["heures"].get("transport_max_minutes", 60)),
        marge_minimum=float(g.get("marge_minimum", 0.0)),
        tarifs={k: dict(v) for k, v in d.get("tarifs", {}).items()},
        tarifs_autres={k: dict(v) for k, v in d.get("tarifs_autres", {}).items()},
        tarif_progression=str(d.get("tarif_progression", {}).get("type", "Appel de service")),
        cout_horaire_defaut=float(d.get("couts", {}).get("defaut", 0.0)),
        couts_techniciens={k: float(v) for k, v in d.get("couts", {}).get("techniciens", {}).items()},
        charges_das=float(d.get("couts", {}).get("das", 0.12)),
        charges_vacances=float(d.get("couts", {}).get("vacances", 0.06)),
        charges_feries=float(d.get("couts", {}).get("feries", 0.05)),
        km_taux=float(d.get("kilometrage", {}).get("taux", 0.61)),
        km_seuil_ecart=float(d.get("kilometrage", {}).get("seuil_ecart_km", 10.0)),
        km_debut_reference=date.fromisoformat(str(d.get("kilometrage", {}).get("debut_reference", "2026-11-08"))),
        salaire_fixe=[str(x) for x in d["transports"].get("salaire_fixe", [])],
        produits_forfait=[str(x) for x in d.get("forfaits", {}).get("produits", [])],
        seuil_rabais=float(g.get("seuil_rabais", 50.0)),
    )


def cents(montant: float) -> float:
    return float(Decimal(str(montant)).quantize(Decimal("0.01"), ROUND_HALF_UP))


def montant_km(km: float, taux: float) -> float:
    """Km × taux arrondi au cent, demi vers le haut, calculé en décimal (17,5 × 0,61 = 10,68 $)."""
    return float((Decimal(str(km)) * Decimal(str(taux))).quantize(Decimal("0.01"), ROUND_HALF_UP))


def heures_fr(heures: float) -> str:
    """12.5 -> « 12,50 », 12.0 -> « 12 »."""
    texte = f"{heures:.2f}".replace(".", ",")
    return texte[:-3] if texte.endswith(",00") else texte


def argent_fr(montant: float) -> str:
    """1000.5 -> « 1 000,50 $ »."""
    return f"{cents(montant):,.2f} $".replace(",", " ").replace(".", ",")


def arrondir_minutes(minutes: float, pas: int = 15) -> int:
    """Arrondit au pas supérieur : 125 -> 135, 135 reste 135, 14 min 40 s -> 15."""
    return math.ceil(round(minutes, 6) / pas) * pas


def heures_facturees(entrees: list[EntreeTemps], pas: int) -> dict[str, float]:
    """Heures facturées par technicien : son total du bon, arrondi au pas supérieur."""
    totaux: dict[str, float] = defaultdict(float)
    for e in entrees:
        totaux[e.technicien] += e.minutes
    return {tech: arrondir_minutes(m, pas) / 60 for tech, m in totaux.items()}


def prix_avec_marge(cout: float, marge: float) -> float:
    return cents(Decimal(str(cout)) * (1 + Decimal(str(marge))))


PRODUIT_MATERIEL = "Matériel acheté"


def total_avant_taxes(facture: Facture) -> float:
    """Sous-total imprimé avant taxes (frais compris); sinon la somme des lignes."""
    if facture.sous_total is not None:
        return cents(facture.sous_total)
    return cents(sum(Decimal(str(l.quantite)) * Decimal(str(l.prix_unitaire)) for l in facture.lignes))


SKU = re.compile(r"\s*\((?:SKU|UGS|CUP|UPC|#)\s*[:#]?\s*[\w-]+\)", re.IGNORECASE)


def corriger_date_facture(d: date | None, date_bon: date | None, jours_max: int,
                          aujourdhui: date | None = None) -> date | None:
    """Date lue avec le jour et le mois inversés (11-04 lu 04-11) : la remet à l'endroit si la date lue est
    impossible (future) ou loin du bon, et que l'inversion tombe près du bon."""
    if d is None or date_bon is None:
        return d
    aujourdhui = aujourdhui or date.today()

    def plausible(x: date) -> bool:
        return x <= aujourdhui and abs((date_bon - x).days) <= jours_max

    if plausible(d) or d.day > 12:
        return d
    try:
        inverse = date(d.year, d.day, d.month)
    except ValueError:
        return d
    return inverse if plausible(inverse) else d


def ligne_materiel(facture: Facture, marge: float) -> Ligne:
    """Comme Hugo : une ligne « Matériel acheté » par facture, quantité 1, articles en description,
    prix = total avant taxes + marge."""
    # Seulement les articles, comme Hugo : fournisseur et numéro de facture restent dans la colonne Origine.
    articles = "\n".join(f"{SKU.sub('', l.description).strip()} ({l.quantite:g})" for l in facture.lignes)
    total = total_avant_taxes(facture)
    return Ligne(
        id=None,
        libelle=PRODUIT_MATERIEL,
        description=articles,
        quantite=1,
        prix=prix_avec_marge(total, marge),
        cout_unitaire=total,
        produit=PRODUIT_MATERIEL,
        external_id=f"{facture.cle}|1",
    )


def garde_fous_facture(facture: Facture, date_bon: date | None, r: Regles,
                       aujourdhui: date | None = None) -> list[Alerte]:
    alertes = []
    nom = f"{facture.fournisseur} {facture.numero}"
    if facture.sous_total is None:
        alertes.append(Alerte(
            "facture_incomplete",
            f"Facture {nom} : aucun sous-total lu (page manquante ?). Le montant vient de la somme des lignes lues : "
            "vérifier la facture complète."))
    if facture.numero.startswith("piece-"):
        alertes.append(Alerte(
            "facture_sans_numero",
            f"Facture {facture.fournisseur} sans numéro lisible : la détection des factures refacturées en double "
            "ne peut pas la reconnaître."))
    if facture.date and facture.date > (aujourdhui or date.today()):
        alertes.append(Alerte("facture_future", f"Facture {nom} datée du {facture.date:%Y-%m-%d}, dans le futur : "
                                                "vérifier la date lue."))
    if facture.sous_total is not None:
        total = sum(Decimal(str(l.quantite)) * Decimal(str(l.prix_unitaire)) for l in facture.lignes)
        ecart = abs(total - Decimal(str(facture.sous_total)))
        if ecart > Decimal(str(r.ecart_sous_total)):
            alertes.append(Alerte(
                "ecart_sous_total",
                f"Facture {nom} : les lignes totalisent {argent_fr(total)}, "
                f"le sous-total imprimé est {argent_fr(facture.sous_total)}."))
    if facture.date and date_bon and abs((date_bon - facture.date).days) > r.jours_max_facture:
        alertes.append(Alerte(
            "facture_ancienne",
            f"Facture {nom} datée du {facture.date:%Y-%m-%d}, à plus de "
            f"{r.jours_max_facture} jours du bon."))
    for l in facture.lignes:
        if l.quantite * l.prix_unitaire > r.montant_max_ligne:
            alertes.append(Alerte(
                "ligne_elevee",
                f"Facture {nom} : « {l.description} » dépasse {argent_fr(r.montant_max_ligne)}."))
    return alertes


REPONSES_SANS_ACHAT = {"non", "no", "nou", "aucun", "aucune", "rien", "0", "-", "n/a", "na", "s/o", "s/0", "so",
                       "aucun achat", "pas d'achat", "pas d’achat"}


def garde_fou_achat(achat: str, nb_factures: int, en_inventaire: bool = False) -> list[Alerte]:
    """Compare le champ « Achat » du technicien aux factures trouvées dans les pièces jointes.

    Un achat facturé en « Matériel en inventaire » n'a jamais de facture (Hugo l'estime) : pas d'alerte.
    """
    declare = (achat or "").strip()
    if not declare:
        return []  # champ non rempli : rien à comparer
    sans_achat = " ".join(declare.lower().strip(" .!").split()) in REPONSES_SANS_ACHAT
    if not sans_achat and nb_factures == 0 and not en_inventaire:
        return [Alerte("achat_sans_facture",
                       f"Le technicien déclare un achat (« {declare} »), mais aucune facture n'a été trouvée "
                       "dans les pièces jointes.")]
    if sans_achat and nb_factures > 0:
        return [Alerte("facture_sans_achat",
                       f"Le technicien a répondu « {declare} » au champ Achat, mais {nb_factures} facture(s) "
                       "ont été trouvées dans les pièces jointes.")]
    return []


def garde_fous_temps(entrees: list[EntreeTemps], r: Regles) -> list[Alerte]:
    if not entrees:
        return [Alerte("sans_heures", "Aucune heure inscrite sur ce bon.", bloquante=True)]
    par_jour: dict[tuple[str, date | None], float] = defaultdict(float)
    for e in entrees:
        par_jour[(e.technicien, e.jour)] += e.minutes
    return [
        Alerte("plus_12h", f"{tech} a {heures_fr(m / 60)} h le {jour}, plus de {heures_fr(r.heures_max_jour)} h.")
        for (tech, jour), m in par_jour.items()
        if m > r.heures_max_jour * 60
    ]
