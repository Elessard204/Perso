"""Client de l'API REST Progression Live. Seul module qui parle à Progression."""

from __future__ import annotations

import base64
import binascii
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta

from modele import Bon, EntreeTemps, Ligne, PieceJointe

BASE = "https://api.progressionlive.com/server/rest"
PAGE = 500  # maximum accepté par /task/list
ESSAIS = 5  # quand Progression demande de ralentir (429)


class ErreurProgression(Exception):
    """Erreur de Progression, avec un message lisible par l'équipe."""


def minutes_iso(duree: str) -> float:
    """Durée ISO 8601 (PT1H20M, PT7M20S, PT1.5H) en minutes exactes.

    Les secondes ne sont pas arrondies ici : on additionne le temps exact du technicien,
    puis on arrondit une seule fois son total (regles.heures_facturees).
    """
    m = re.fullmatch(r"P(?:([\d.]+)D)?T?(?:([\d.]+)H)?(?:([\d.]+)M)?(?:([\d.]+)S)?", duree or "")
    if not m or not duree:
        return 0.0
    jours, heures, minutes, secondes = (float(x) if x else 0.0 for x in m.groups())
    return jours * 1440 + heures * 60 + minutes + secondes / 60


def _jour(horodatage: str | None) -> date | None:
    if not horodatage:
        return None
    try:
        return date.fromisoformat(horodatage[:10])
    except ValueError:
        return None


def _libelle(ref) -> str:
    if isinstance(ref, list):
        ref = ref[0] if ref else {}
    return (ref or {}).get("label") or ""


def _horodatage(texte: str | None) -> datetime | None:
    if not texte:
        return None
    try:
        return datetime.fromisoformat(re.sub(r"([+-]\d{2})$", r"\1:00", texte))
    except ValueError:
        return None


def lire_champ(tache: dict, champ: str) -> str:
    """Lit « description » ou un champ personnalisé « properties.info.notes ».

    Progression renvoie les champs personnalisés à plat (clé « info.notes ») ; un objet imbriqué
    ({"info": {"notes": ...}}) est aussi accepté.
    """
    if champ.startswith("properties."):
        proprietes = tache.get("properties") or {}
        cle = champ[len("properties."):]
        if isinstance(proprietes.get(cle), str):
            return proprietes[cle]
    valeur = tache
    for partie in champ.split("."):
        valeur = (valeur or {}).get(partie) if isinstance(valeur, dict) else None
    return valeur if isinstance(valeur, str) else ""


def bon_depuis_json(tache: dict, entrees: list[dict], cfg: dict) -> Bon:
    lignes = []
    for it in (tache.get("itemList") or {}).get("items") or []:
        produit = it.get("product") or {}
        lignes.append(Ligne(
            id=it.get("id"),
            libelle=it.get("label") or "",
            description=it.get("description") or "",
            quantite=float(it.get("quantity") or 0),
            prix=float(it.get("price") or 0),
            cout_unitaire=float(it["unitCost"]) if it.get("unitCost") is not None else None,
            produit=produit.get("label") or produit.get("code"),
            external_id=it.get("externalId"),
        ))
    return Bon(
        id=tache["id"],
        code=tache.get("code") or "",
        client=_libelle(tache.get("client")),
        date_rv=_jour(tache.get("rv")),
        maj=tache.get("updated") or "",
        description=lire_champ(tache, cfg.get("champ_description") or "description"),
        entrees=[
            EntreeTemps(
                id=e["id"],
                technicien=_libelle(e.get("humanResource")),
                jour=_jour(e.get("start")),
                minutes=minutes_iso(e.get("duration") or ""),
                ligne_id=(e.get("item") or {}).get("id"),
                activite=_libelle(e.get("activity")),
                debut=_horodatage(e.get("start")),
                cout_horaire=float(e["averageHourlyCost"]) if e.get("averageHourlyCost") is not None else None,
            )
            for e in entrees
        ],
        lignes=lignes,
        pieces=[
            PieceJointe(id=a["id"], nom=a.get("name") or "", type_mime=a.get("contentType") or "")
            for a in tache.get("attachments") or []
        ],
        achat=lire_champ(tache, cfg["champ_achat"]) if cfg.get("champ_achat") else "",
        type_bon=_libelle(tache.get("type")),
        lieu=f"{(tache.get('client') or {}).get('id', '')}/{(tache.get('location') or {}).get('id', '')}",
        lieu_libelle=" – ".join(x for x in (_libelle(tache.get("client")), _libelle(tache.get("location"))) if x),
        demande="\n".join(x for x in (tache.get("summary") or "", tache.get("description") or "") if x.strip()),
    )


def _liste(reponse) -> list[dict]:
    """/task/list renvoie une liste; on accepte aussi une enveloppe {"data": [...]}."""
    if isinstance(reponse, list):
        return reponse
    if isinstance(reponse, dict):
        for valeur in reponse.values():
            if isinstance(valeur, list):
                return valeur
    return []


class Progression:
    def __init__(self, cle: str, base: str = BASE, ouvrir=urllib.request.urlopen, cfg: dict | None = None,
                 dormir=time.sleep):
        self.cle = cle
        self.base = base.rstrip("/")
        self.ouvrir = ouvrir
        self.cfg = cfg or {}
        self.dormir = dormir

    def _appel(self, methode: str, chemin: str, params: dict | None = None, corps: dict | None = None):
        url = self.base + chemin
        if params:
            url += "?" + urllib.parse.urlencode({k: v for k, v in params.items() if v not in (None, "")})
        donnees = json.dumps(corps).encode("utf-8") if corps is not None else None
        requete = urllib.request.Request(url, data=donnees, method=methode, headers={
            "Authorization": f"Bearer {self.cle}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        })
        for essai in range(ESSAIS):
            try:
                with self.ouvrir(requete, timeout=60) as reponse:
                    texte = reponse.read().decode("utf-8")
                break
            except urllib.error.HTTPError as e:
                if e.code == 429:
                    if essai == ESSAIS - 1:
                        raise ErreurProgression(
                            "Progression reçoit trop de demandes : réessayer dans quelques minutes.") from e
                    try:
                        attente = float((e.headers or {}).get("Retry-After") or "")
                    except ValueError:
                        attente = 2.0 * 2 ** essai
                    self.dormir(min(attente, 60.0))
                    continue
                if e.code in (401, 403):
                    raise ErreurProgression(
                        "Clé Progression refusée ou permissions insuffisantes. "
                        "Vérifier la clé dans les paramètres.") from e
                if e.code == 404:
                    raise ErreurProgression(f"Élément introuvable dans Progression ({chemin}).") from e
                raise ErreurProgression(f"Progression a répondu une erreur {e.code} ({chemin}).") from e
            except (urllib.error.URLError, TimeoutError, OSError) as e:
                raise ErreurProgression(
                    "Progression ne répond pas. Vérifier la connexion Internet et réessayer.") from e
        return json.loads(texte) if texte.strip() else {}

    def lister_bons(self, logic_ids: str, type_tache: str, rv: str) -> list[dict]:
        taches: list[dict] = []
        debut = 0
        while True:
            page = _liste(self._appel("GET", "/task/list", {
                "logicId": logic_ids, "type": type_tache, "rv": rv,
                "maxResults": PAGE, "startResult": debut,
            }))
            taches.extend(page)
            if len(page) < PAGE:
                return taches
            debut += PAGE

    def lister_recents(self, logic_ids: str, nombre: int) -> list[dict]:
        """Les derniers bons modifiés, pour l'inspection."""
        return _liste(self._appel("GET", "/task/list", {
            "logicId": logic_ids, "order": "updated DESC", "maxResults": nombre, "startResult": 0,
        }))[:nombre]

    def tache_brute(self, identifiant: int) -> dict:
        """La tâche seule (sans entrées de temps), pour vérifier qu'elle n'a pas changé avant d'écrire."""
        return self._appel("GET", f"/task/{identifiant}")

    def lire_tache(self, identifiant: int) -> tuple[dict, list[dict]]:
        """La tâche et ses entrées de temps, telles que Progression les renvoie."""
        tache = self._appel("GET", f"/task/{identifiant}")
        return tache, _liste(self._appel("GET", f"/task/{identifiant}/timeEntries"))

    def entrees_periode(self, debut: date, fin: date) -> list[dict]:
        """Les entrées de temps de tous les bons entre deux dates (lecture seule, paginée).

        La marge d'un jour de chaque côté compense l'absence de fuseau dans la requête;
        km_calcul.journees refiltre par date locale.
        """
        periode = f"{(debut - timedelta(days=1)).isoformat()}T00:00:00-05,{(fin + timedelta(days=1)).isoformat()}T23:59:59-05"
        entrees: list[dict] = []
        decalage = 0
        while True:
            page = _liste(self._appel("GET", "/timeEntry/list", {
                "start": periode, "maxResults": PAGE, "startResult": decalage,
            }))
            entrees.extend(page)
            if len(page) < PAGE:
                return entrees
            decalage += PAGE

    def lire_bon(self, identifiant: int) -> Bon:
        tache, entrees = self.lire_tache(identifiant)
        return bon_depuis_json(tache, entrees, self.cfg)

    def telecharger_piece(self, piece_id: int) -> bytes:
        piece = self._appel("GET", f"/task/attachment/{piece_id}")
        try:
            return base64.b64decode(piece.get("data") or "", validate=True)
        except (binascii.Error, ValueError) as e:
            raise ErreurProgression(f"Pièce jointe {piece_id} illisible (contenu reçu invalide).") from e

    def bon_avec_ligne(self, external_id: str) -> int | None:
        """Le bon qui porte déjà une ligne avec cet externalId, s'il y en a un."""
        taches = _liste(self._appel("GET", "/task/list", {"itemExternalId": external_id, "maxResults": 1}))
        return taches[0].get("id") if taches else None

    def mettre_a_jour(self, identifiant: int, corps: dict) -> dict:
        return self._appel("POST", f"/task/{identifiant}/update", corps=corps)
